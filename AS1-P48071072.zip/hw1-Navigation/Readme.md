#How to execute the program
At hw1-Navigation directroy

Arguments:
    -h : help
    -p : planning type, 0: A-Star, 1: RRT-Star
    -c : Control type, 0: Pure Persuit, 1: Stanley

For example:
    $ python main.py -p 0 -c 0